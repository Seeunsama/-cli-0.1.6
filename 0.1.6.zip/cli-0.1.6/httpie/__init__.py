"""
HTTPie - cURL for humans.

"""
__author__ = 'Jakub Roztocil'
__version__ = '0.1.6'
__licence__ = 'BSD'
